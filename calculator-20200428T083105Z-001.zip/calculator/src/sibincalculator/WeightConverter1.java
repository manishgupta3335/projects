package sibincalculator;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author manish gupta
 */
import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import javax.swing.*;
public class WeightConverter1{
    private JFrame frame;
    private JLabel welcomeLabel;
    private JPanel fromPanel;
    private JLabel centerLabel;
    private JTextField fromField;
    private JComboBox<String> fromBox;
    private JPanel toPanel;
    private JTextField toField;
    private JComboBox<String> toBox;
    private JButton submitButton;
    private JLabel noteLabel;
    private JPanel bottomPanel;
    private final String[] WeightTypes = {"Grams", "Dekagrams", "Hectograms", "Kilograms", "Ounces", "Pound","Stones"};
    private final HashMap<String, HashMap<String, Double>> conversions = new HashMap<>();
    public WeightConverter1() {
        conversions.put("Grams", new HashMap<>());

        conversions.get("Grams").put("Grams", 1.0);
        conversions.get("Grams").put("Dekagrams", 0.1);
        conversions.get("Grams").put("Hectograms", 0.01);
        conversions.get("Grams").put("Kilograms", 0.001);
        conversions.get("Grams").put("Ounces", 0.035274);
        conversions.get("Grams").put("Pound", 0.00220462);
        conversions.get("Grams").put("Stones", 0.000157473);

        conversions.put("Dekagrams", new HashMap<>());

        conversions.get("Dekagrams").put("Grams", 10.0);
        conversions.get("Dekagrams").put("Dekagrams", 1.0);
        conversions.get("Dekagrams").put("Hectograms", 0.1);
        conversions.get("Dekagrams").put("Kilograms", 0.01);
        conversions.get("Dekagrams").put("Ounces", 0.35274);
        conversions.get("Dekagrams").put("Pound", 0.0220462);
        conversions.get("Dekagrams").put("Stones", 0.00157473);


        conversions.put("Hectograms", new HashMap<>());
        
        conversions.get("Hectograms").put("Grams", 100.0);
        conversions.get("Hectograms").put("Dekagrams", 10.0);
        conversions.get("Hectograms").put("Hectograms", 1.0);
        conversions.get("Hectograms").put("Kilograms", 0.1);
        conversions.get("Hectograms").put("Ounces", 3.5274);
        conversions.get("Hectograms").put("Pound", 0.220462);
        conversions.get("Hectograms").put("Stones", 0.0157473);

        

        conversions.put("Kilograms", new HashMap<>());

        conversions.get("Kilograms").put("Grams", 1000.0);
        conversions.get("Kilograms").put("Dekagrams", 100.0);
        conversions.get("Kilograms").put("Hectograms", 10.0);
        conversions.get("Kilograms").put("Kilograms", 1.0);
        conversions.get("Kilograms").put("Ounces", 35.274);
        conversions.get("Kilograms").put("Pound", 2.20462);
        conversions.get("Kilograms").put("Stones", 0.157473);

        

        conversions.put("Ounces", new HashMap<>());

        conversions.get("Ounces").put("Grams", 28.3495);
        conversions.get("Ounces").put("Dekagrams", 2.83495);
        conversions.get("Ounces").put("Hectograms", 0.283495);
        conversions.get("Ounces").put("Kilograms", 0.0283495);
        conversions.get("Ounces").put("Ounces", 1.0);
        conversions.get("Ounces").put("Pound", 0.0625);
        conversions.get("Ounces").put("Stones", 0.00446429);

        conversions.put("Pound", new HashMap<>());

        conversions.get("Pound").put("Grams", 453.592);
        conversions.get("Pound").put("Dekagrams", 45.3592);
        conversions.get("Pound").put("Hectograms", 4.53592);
        conversions.get("Pound").put("Kilograms", 0.453592);
        conversions.get("Pound").put("Ounces", 16.0);
        conversions.get("Pound").put("Pound", 1.0);
        conversions.get("Pound").put("Stones", 0.0714286);
        
         conversions.put("Stones", new HashMap<>());

        conversions.get("Stones").put("Grams", 6350.29);
        conversions.get("Stones").put("Dekagrams", 635.029);
        conversions.get("Stones").put("Hectograms", 63.5029);
        conversions.get("Stones").put("Kilograms", 6.35029);
        conversions.get("Stones").put("Ounces", 224.0);
        conversions.get("Stones").put("Pound", 14.0);
        conversions.get("Stones").put("Stones", 1.0);
    }
    public static void main(String[] args) {
        new WeightConverter1().go();
    }
    public void go() {
        frame = new JFrame("Weight Conversions");
        fromPanel = new JPanel();
        centerLabel = new JLabel("..To..");
        fromField = new JTextField(10);
        fromBox = new JComboBox<>(WeightTypes);
        toPanel = new JPanel();
        toBox = new JComboBox<>(WeightTypes);
        toField = new JTextField(10);
        toField.setEnabled(false);
        welcomeLabel = new JLabel("Welcome to the Weight converter!");
        submitButton = new JButton("Convert!");
        noteLabel = new JLabel("Note: Rounds to fit the text field.");
        bottomPanel = new JPanel();
        submitButton.addActionListener(new SubmitListener());

        fromPanel.setLayout(new BoxLayout(fromPanel, BoxLayout.X_AXIS));
        fromPanel.add(fromField);
        fromPanel.add(fromBox);

        toPanel.setLayout(new BoxLayout(toPanel, BoxLayout.X_AXIS));
        toPanel.add(toField);
        toPanel.add(toBox);

        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.X_AXIS));
        bottomPanel.add(noteLabel);
        bottomPanel.add(submitButton);

        Font labelFont = new Font("Arial", Font.BOLD, 24);
        welcomeLabel.setFont(labelFont);

        frame.setLayout(new BorderLayout());
        Container window = frame.getContentPane();

        window.add(BorderLayout.NORTH, welcomeLabel);
        window.add(BorderLayout.WEST, fromPanel);
        window.add(BorderLayout.EAST, toPanel);
        window.add(BorderLayout.CENTER, centerLabel);
        window.add(BorderLayout.SOUTH, bottomPanel);

        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
    class SubmitListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try
            {
            Double numToConvert = Double.parseDouble(fromField.getText());
            Double conversionRate = conversions.get(fromBox.getSelectedItem()).get(toBox.getSelectedItem());
            String result = Double.toString(numToConvert * conversionRate);
            int length = result.length();
            if (length > 4) {
                Dimension d = frame.getSize();
                frame.setSize(length + d.width - 16, d.height);
                toField.setColumns(length);
            }
            else {
                toField.setColumns(4);
                frame.pack();
            }
            toField.setText(result);
            frame.revalidate();
            }
              catch(Exception f)
{
   JOptionPane.showMessageDialog(null,"Invalid Input");
}
            }

    }
}