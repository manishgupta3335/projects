package sibincalculator;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author manish gupta
 */
import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import javax.swing.*;
public class PressureConverter{
    private JFrame frame;
    private JLabel welcomeLabel;
    private JPanel fromPanel;
    private JLabel centerLabel;
    private JTextField fromField;
    private JComboBox<String> fromBox;
    private JPanel toPanel;
    private JTextField toField;
    private JComboBox<String> toBox;
    private JButton submitButton;
    private JLabel noteLabel;
    private JPanel bottomPanel;
    private final String[] PressureTypes = {"Atmosphere","Bars","Kilopascal","Millimeter_Of_Mercury","Pascal"};
    private final HashMap<String, HashMap<String, Double>> conversions = new HashMap<>();
    public PressureConverter() {
        conversions.put("Atmosphere", new HashMap<>());

        conversions.get("Atmosphere").put("Atmosphere", 1.0);
        conversions.get("Atmosphere").put("Bars", 1.01325);
        conversions.get("Atmosphere").put("Kilopascal", 101.325);
        conversions.get("Atmosphere").put("Millimeter_Of_Mercury", 760.0);
        conversions.get("Atmosphere").put("Pascal", 101325.0);
      

        conversions.put("Bars", new HashMap<>());

        conversions.get("Bars").put("Atmosphere", 0.986923);
        conversions.get("Bars").put("Bars", 1.0);
        conversions.get("Bars").put("Kilopascal", 100.0);
        conversions.get("Bars").put("Millimeter_Of_Mercury", 750.062);
        conversions.get("Bars").put("Pascal", 100000.0);
       
        
        conversions.put("Kilopascal", new HashMap<>());

        conversions.get("Kilopascal").put("Atmosphere", 0.00986923);
        conversions.get("Kilopascal").put("Bars", 0.01);
        conversions.get("Kilopascal").put("Kilopascal", 1.0);
        conversions.get("Kilopascal").put("Millimeter_Of_Mercury", 7.50062);
        conversions.get("Kilopascal").put("Pascal", 1000.0);
        
        conversions.put("Millimeter_Of_Mercury", new HashMap<>());

        conversions.get("Millimeter_Of_Mercury").put("Atmosphere", 0.00131579);
        conversions.get("Millimeter_Of_Mercury").put("Bars", 0.00133322);
        conversions.get("Millimeter_Of_Mercury").put("Kilopascal", 0.133322);
        conversions.get("Millimeter_Of_Mercury").put("Millimeter_Of_Mercury", 133.322);
        conversions.get("Millimeter_Of_Mercury").put("Pascal", 1.0);
        
        conversions.put("Pascal", new HashMap<>());

        conversions.get("Pascal").put("Atmosphere", 9.86923e-6);
        conversions.get("Pascal").put("Bars", 1e-5);
        conversions.get("Pascal").put("Kilopascal", 0.001);
        conversions.get("Pascal").put("Millimeter_Of_Mercury", 0.00750062);
        conversions.get("Pascal").put("Pascal", 1.0);
        
        
    }
    public static void main(String[] args) {
        new PressureConverter().go();
    }
    public void go() {
        frame = new JFrame("Pressure Conversions");
        fromPanel = new JPanel();
        centerLabel = new JLabel("..to..");
        fromField = new JTextField(10);
        fromBox = new JComboBox<>(PressureTypes);
        toPanel = new JPanel();
        toBox = new JComboBox<>(PressureTypes);
        toField = new JTextField(10);
        toField.setEnabled(false);
        welcomeLabel = new JLabel("Welcome to the Temperature converter!");
        submitButton = new JButton("Convert!");
        noteLabel = new JLabel("Note: Rounds to fit the text field.");
        bottomPanel = new JPanel();
        submitButton.addActionListener(new SubmitListener());

        fromPanel.setLayout(new BoxLayout(fromPanel, BoxLayout.X_AXIS));
        fromPanel.add(fromField);
        fromPanel.add(fromBox);

        toPanel.setLayout(new BoxLayout(toPanel, BoxLayout.X_AXIS));
        toPanel.add(toField);
        toPanel.add(toBox);

        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.X_AXIS));
        bottomPanel.add(noteLabel);
        bottomPanel.add(submitButton);

        Font labelFont = new Font("Arial", Font.BOLD, 24);
        welcomeLabel.setFont(labelFont);

        frame.setLayout(new BorderLayout());
        Container window = frame.getContentPane();

        window.add(BorderLayout.NORTH, welcomeLabel);
        window.add(BorderLayout.WEST, fromPanel);
        window.add(BorderLayout.EAST, toPanel);
        window.add(BorderLayout.CENTER, centerLabel);
        window.add(BorderLayout.SOUTH, bottomPanel);

        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
    class SubmitListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try
            {
            Double numToConvert = Double.parseDouble(fromField.getText());
            Double conversionRate = conversions.get(fromBox.getSelectedItem()).get(toBox.getSelectedItem());
            String result = Double.toString(numToConvert * conversionRate);
            int length = result.length();
            if (length > 4) {
                Dimension d = frame.getSize();
                frame.setSize(length + d.width - 16, d.height);
                toField.setColumns(length);
            }
            else {
                toField.setColumns(4);
                frame.pack();
            }
            toField.setText(result);
            frame.revalidate();
            }
            catch(Exception f)
{
   JOptionPane.showMessageDialog(null,"Invalid Input");
}
        }

    }
}