package sibincalculator;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author manish gupta
 */
import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import javax.swing.*;
public class TemperatureConverter{
    private JFrame frame;
    private JLabel welcomeLabel;
    private JPanel fromPanel;
    private JLabel centerLabel;
    private JTextField fromField;
    private JComboBox<String> fromBox;
    private JPanel toPanel;
    private JTextField toField;
    private JComboBox<String> toBox;
    private JButton submitButton;
    private JLabel noteLabel;
    private JPanel bottomPanel;
    private final String[] lengthTypes = {"Celcius","Fahrenheit","Kelvin"};
    private final HashMap<String, HashMap<String, Double>> conversions = new HashMap<>();
    public TemperatureConverter() {
        conversions.put("Celcius", new HashMap<>());

        conversions.get("Celcius").put("Celcius", 1.0);
        conversions.get("Celcius").put("Fahrenheit", 32.0);
        conversions.get("Celcius").put("Kelvin", 273.15);
      

        conversions.put("Fahrenheit", new HashMap<>());

        conversions.get("Fahrenheit").put("Celcius", -17.22222);
        conversions.get("Fahrenheit").put("Fahrenheit", 1.0);
        conversions.get("Fahrenheit").put("Kelvin", 255.9278);

        conversions.put("Kelvin", new HashMap<>());

        conversions.get("Kelvin").put("Celcius", -273.15);
        conversions.get("Kelvin").put("Fahrenheit", -457.87);
        conversions.get("Kelvin").put("Kelvin", 1.0);
        
        
    }
    public static void main(String[] args) {
        new TemperatureConverter().go();
    }
    public void go() {
        frame = new JFrame("Length Conversions");
        fromPanel = new JPanel();
        centerLabel = new JLabel("Is...");
        fromField = new JTextField(10);
        fromBox = new JComboBox<>(lengthTypes);
        toPanel = new JPanel();
        toBox = new JComboBox<>(lengthTypes);
        toField = new JTextField(10);
        toField.setEnabled(false);
        welcomeLabel = new JLabel("Welcome to the Temperature converter!");
        submitButton = new JButton("Convert!");
        noteLabel = new JLabel("Note: Rounds to fit the text field.");
        bottomPanel = new JPanel();
        submitButton.addActionListener(new SubmitListener());

        fromPanel.setLayout(new BoxLayout(fromPanel, BoxLayout.X_AXIS));
        fromPanel.add(fromField);
        fromPanel.add(fromBox);

        toPanel.setLayout(new BoxLayout(toPanel, BoxLayout.X_AXIS));
        toPanel.add(toField);
        toPanel.add(toBox);

        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.X_AXIS));
        bottomPanel.add(noteLabel);
        bottomPanel.add(submitButton);

        Font labelFont = new Font("Arial", Font.BOLD, 24);
        welcomeLabel.setFont(labelFont);

        frame.setLayout(new BorderLayout());
        Container window = frame.getContentPane();

        window.add(BorderLayout.NORTH, welcomeLabel);
        window.add(BorderLayout.WEST, fromPanel);
        window.add(BorderLayout.EAST, toPanel);
        window.add(BorderLayout.CENTER, centerLabel);
        window.add(BorderLayout.SOUTH, bottomPanel);

        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
    class SubmitListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try
            {
            Double numToConvert = Double.parseDouble(fromField.getText());
            Double conversionRate = conversions.get(fromBox.getSelectedItem()).get(toBox.getSelectedItem());
            String result = Double.toString(numToConvert * conversionRate);
            int length = result.length();
            if (length > 4) {
                Dimension d = frame.getSize();
                frame.setSize(length + d.width - 16, d.height);
                toField.setColumns(length);
            }
            else {
                toField.setColumns(4);
                frame.pack();
            }
            toField.setText(result);
            frame.revalidate();
            }
            catch(Exception f)
{
   JOptionPane.showMessageDialog(null,"Invalid Input");
}
            }

    }
}