package sibincalculator;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author manish gupta
 */
import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import javax.swing.*;
public class AreaConverter{
    private JFrame frame;
    private JLabel welcomeLabel;
    private JPanel fromPanel;
    private JLabel centerLabel;
    private JTextField fromField;
    private JComboBox<String> fromBox;
    private JPanel toPanel;
    private JTextField toField;
    private JComboBox<String> toBox;
    private JButton submitButton;
    private JLabel noteLabel;
    private JPanel bottomPanel;
    private final String[] AreaTypes = {"Square_Millimeter","Square_Centimeters","Square_Meters","Hectare","Square_Kilometer","Square_Feet","Square_Yards","Acre","Square_Mile"};
    private final HashMap<String, HashMap<String, Double>> conversions = new HashMap<>();
    public AreaConverter() {
        conversions.put("Square_Millimeter", new HashMap<>());

        conversions.get("Square_Millimeter").put("Square_Millimeter", 1.0);
        conversions.get("Square_Millimeter").put("Square_ Centimeters", 0.01);
        conversions.get("Square_Millimeter").put("Square_Meter", 0.000001);
        conversions.get("Square_Millimeter").put("Hactare", 0.0000000001);
        conversions.get("Square_Millimeter").put("Square_Kilometer", 0.000000000001);
        conversions.get("Square_Millimeter").put("Square_Feet", 0.000011);
        conversions.get("Square_Millimeter").put("Square_Yard", 0.000001);
        conversions.get("Square_Millimeter").put("Acre", 0.0000000002471);
        conversions.get("Square_Millimeter").put("Square_Mile", 0.00000000000039);

        conversions.put("Square_Centimeters", new HashMap<>());
        
        conversions.get("Square_Centimeters").put("Square_Millimeter", 100.0);
        conversions.get("Square_Centimeters").put("Square_ Centimeters", 1.0);
        conversions.get("Square_Centimeters").put("Square_Meter", 0.0001);
        conversions.get("Square_Centimeters").put("Hactare", 0.00000001);
        conversions.get("Square_Centimeters").put("Square_Kilometer", 0.0000000001);
        conversions.get("Square_Centimeters").put("Square_Feet", 0.001076);
        conversions.get("Square_Centimeters").put("Square_Yard", 0.00012);
        conversions.get("Square_Centimeters").put("Acre", 0.00000002471054);
        conversions.get("Square_Centimeters").put("Square_Mile", 0.00000000003861);

        

        conversions.put("Square_Meters", new HashMap<>());

        conversions.get("Square_Meters").put("Square_Millimeter", 100000.0);
        conversions.get("Square_Meters").put("Square_ Centimeters", 10000.0);
        conversions.get("Square_Meters").put("Square_Meter", 1.0);
        conversions.get("Square_Meters").put("Hactare", 0.0001);
        conversions.get("Square_Meters").put("Square_Kilometer", 0.000001);
        conversions.get("Square_Meters").put("Square_Feet", 10.76391);
        conversions.get("Square_Meters").put("Square_Yard", 1.19599);
        conversions.get("Square_Meters").put("Acre", 0.000247);
        conversions.get("Square_Meters").put("Square_Mile", 0.000000386102);

        conversions.put("Hectare", new HashMap<>());

        conversions.get("Hectare").put("Square_Millimeter", 10000000000.0);
        conversions.get("Hectare").put("Square_ Centimeters", 100000000.0);
        conversions.get("Hectare").put("Square_Meter", 10000.0);
        conversions.get("Hectare").put("Hactare", 1.0);
        conversions.get("Hectare").put("Square_Kilometer", 0.01);
        conversions.get("Hectare").put("Square_Feet", 107639.0);
        conversions.get("Hectare").put("Square_Yard", 11959.9);
        conversions.get("Hectare").put("Acre", 2.47105);
        conversions.get("Hectare").put("Square_Mile", 0.00386102);

        conversions.put("Square_Kilometer", new HashMap<>());

        conversions.get("Square_Kilometer").put("Square_Millimeter", 1000000000000.0);
        conversions.get("Square_Kilometer").put("Square_ Centimeters", 10000000000.0);
        conversions.get("Square_Kilometer").put("Square_Meter", 1000000.0);
        conversions.get("Square_Kilometer").put("Hactare", 100.0);
        conversions.get("Square_Kilometer").put("Square_Kilometer", 1.0);
        conversions.get("Square_Kilometer").put("Square_Feet", 10763910.0);
        conversions.get("Square_Kilometer").put("Square_Yard", 1195910.0);
        conversions.get("Square_Kilometer").put("Acre", 247.1054);
        conversions.get("Square_Kilometer").put("Square_Mile", 0.386102);

        conversions.put("Square_Feet", new HashMap<>());

        conversions.get("Square_Feet").put("Square_Millimeter", 92903.04);
        conversions.get("Square_Feet").put("Square_ Centimeters", 929.03);
        conversions.get("Square_Feet").put("Square_Meter", 0.092903);
        conversions.get("Square_Feet").put("Hactare", 9.2903e-6);
        conversions.get("Square_Feet").put("Square_Kilometer", 9.2903e-8);
        conversions.get("Square_Feet").put("Square_Feet", 1.0);
        conversions.get("Square_Feet").put("Square_Yard", 0.111111);
        conversions.get("Square_Feet").put("Acre", 2.29568e-5);
        conversions.get("Square_Feet").put("Square_Mile", 3.58701e-8);

        
        conversions.put("Square_Yards", new HashMap<>());

        conversions.get("Square_Yards").put("Square_Millimeter", 836127.0);
        conversions.get("Square_Yards").put("Square_ Centimeters", 8361.27);
        conversions.get("Square_Yards").put("Square_Meter", 0.836127);
        conversions.get("Square_Yards").put("Hactare", 8.36127e-5);
        conversions.get("Square_Yards").put("Square_Kilometer", 8.36127e-7);
        conversions.get("Square_Yards").put("Square_Feet", 9.0);
        conversions.get("Square_Yards").put("Square_Yard", 1.0);
        conversions.get("Square_Yards").put("Acre", 0.000206612);
        conversions.get("Square_Yards").put("Square_Mile", 3.22831e-7);
        
         conversions.put("Acre", new HashMap<>());

        conversions.get("Acre").put("Square_Millimeter", 4.047e+9);
        conversions.get("Acre").put("Square_ Centimeters",4.047e+7);
        conversions.get("Acre").put("Square_Meter", 4046.86);
        conversions.get("Acre").put("Hactare", 0.404686);
        conversions.get("Acre").put("Square_Kilometer", 0.00404686);
        conversions.get("Acre").put("Square_Feet", 43560.0);
        conversions.get("Acre").put("Square_Yard", 4840.0);
        conversions.get("Acre").put("Acre", 1.0);
        conversions.get("Acre").put("Square_Mile", 0.0015625);
        
          conversions.put("Square_Mile", new HashMap<>());

        conversions.get("Square_Mile").put("Square_Millimeter", 2.59e+12);
        conversions.get("Square_Mile").put("Square_ Centimeters", 2.59e+10);
        conversions.get("Square_Mile").put("Square_Meter", 2.59e+6);
        conversions.get("Square_Mile").put("Hactare",258.999 );
        conversions.get("Square_Mile").put("Square_Kilometer", 2.58999);
        conversions.get("Square_Mile").put("Square_Feet", 2.788e+7);
        conversions.get("Square_Mile").put("Square_Yard", 3.098e+6);
        conversions.get("Square_Mile").put("Acre", 640.0);
        conversions.get("Square_Mile").put("Square_Mile", 1.0);
    }
    public static void main(String[] args) {
        new AreaConverter().go();
    }
    public void go() {
        frame = new JFrame("Area Conversions");
        fromPanel = new JPanel();
        centerLabel = new JLabel("..To..");
        fromField = new JTextField(10);
        fromBox = new JComboBox<>(AreaTypes);
        toPanel = new JPanel();
        toBox = new JComboBox<>(AreaTypes);
        toField = new JTextField(10);
        toField.setEnabled(false);
        welcomeLabel = new JLabel("Welcome to the Area converter!");
        submitButton = new JButton("Convert!");
        noteLabel = new JLabel("Note: Rounds to fit the text field.");
        bottomPanel = new JPanel();
        submitButton.addActionListener(new SubmitListener());

        fromPanel.setLayout(new BoxLayout(fromPanel, BoxLayout.X_AXIS));
        fromPanel.add(fromField);
        fromPanel.add(fromBox);

        toPanel.setLayout(new BoxLayout(toPanel, BoxLayout.X_AXIS));
        toPanel.add(toField);
        toPanel.add(toBox);

        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.X_AXIS));
        bottomPanel.add(noteLabel);
        bottomPanel.add(submitButton);

        Font labelFont = new Font("Arial", Font.BOLD, 24);
        welcomeLabel.setFont(labelFont);

        frame.setLayout(new BorderLayout());
        Container window = frame.getContentPane();

        window.add(BorderLayout.NORTH, welcomeLabel);
        window.add(BorderLayout.WEST, fromPanel);
        window.add(BorderLayout.EAST, toPanel);
        window.add(BorderLayout.CENTER, centerLabel);
        window.add(BorderLayout.SOUTH, bottomPanel);

        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
    class SubmitListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
           
          try
          {Double numToConvert = Double.parseDouble(fromField.getText());
            Double conversionRate = conversions.get(fromBox.getSelectedItem()).get(toBox.getSelectedItem());
            String result = Double.toString(numToConvert * conversionRate);
            int length = result.length();
            if (length > 4) {
                Dimension d = frame.getSize();
                frame.setSize(length + d.width - 16, d.height);
                toField.setColumns(length);
            }
            else {
                toField.setColumns(4);
                frame.pack();
            }
            toField.setText(result);
            frame.revalidate();
          }
          catch(Exception f)
{
   JOptionPane.showMessageDialog(null,"Invalid Input");
}
        }

    }
}