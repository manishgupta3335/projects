/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author manish gupta
 */
/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sibincalculator;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 *
 * @author MANISH GUPTA
 */
public class calcu6 extends JFrame implements ActionListener {

    JLabel de1, mo1, ye1, de2, mo2, ye2, de;
    JTextField di1, mi1, yi1, di2, mi2, yi2, di;
    JButton ok, reset;

    calcu6() {
        super("The Time Interval");
        Container c = getContentPane();
        c.setLayout(new FlowLayout());
        

        de2 = new JLabel("DayFrom :");
        di2 = new JTextField(2);

        mo2 = new JLabel("monthFrom :");
        mi2 = new JTextField(2);

        ye2 = new JLabel("yearFrom :");
        yi2 = new JTextField(4);

        de1 = new JLabel("DayTo:");
        di1 = new JTextField(2);

        mo1 = new JLabel("MonthTo :");
        mi1 = new JTextField(2);

        ye1 = new JLabel("YearTo:");
        yi1 = new JTextField(4);
      
        de = new JLabel("Interval:");
        di = new JTextField(20);

        ok = new JButton("Calculate");
        reset = new JButton("Reset");
        ok.addActionListener(this);
        reset.addActionListener(this);

        

        c.add(de2);
        c.add(di2);

        c.add(mo2);
        c.add(mi2);

        c.add(ye2);
        c.add(yi2);

        c.add(de);
        c.add(di);
        
        c.add(de1);
        c.add(di1);

        c.add(mo1);
        c.add(mi1);

        c.add(ye1);
        c.add(yi1);

        c.add(ok);
        c.add(reset);
        setSize(500, 300);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        JButton but = (JButton) e.getSource();
        
        try
        {
        if (but.getText() == "Calculate") {
            int d1 = Integer.parseInt(di1.getText());
            int m1 = Integer.parseInt(mi1.getText());
            int y1 = Integer.parseInt(yi1.getText());
            int d2 = Integer.parseInt(di2.getText());
            int m2 = Integer.parseInt(mi2.getText());
            int y2 = Integer.parseInt(yi2.getText());
            //int d1,d2,m1,m2,y1,y2;
            int[] mo = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
            int m3 = 0;
            int y3 = 0;
            int d = 0;
            int m = 0;
            int y = 0;
            if ((y1 % 4 == 0) && (y1 % 400 == 0)) {

                mo[1] = 29;
            } else {
                mo[1] = 28;
            }
            for (int i = 0; i < mo.length; i++) {
                if (d1 < d2) {
                    d = d1 + mo[m1 - 1] - d2;
                    m3 = m1 - 1;
                    if (m3 < m2) {
                        m = m3 + 12 - m2;
                        y3 = y1 - 1;
                        y = y3 - y2;
                    } else {
                        m = m1 - m2;
                        y = y1 - y2;
                    }
                } else {
                    d = d1 - d2;
                    if (m1 < m2) {
                        m = m1 + 12 - m2;
                        y = y1 - 1 - y2;
                    } else {
                        m = m1 - m2;
                        y = y1 - y2;
                    }
                }
            }

            di.setText("Day :" + Integer.toString(d) + "  " + "Month :" + Integer.toString(m) + "  " + "Year :" + Integer.toString(y));
        } else if (but.getText() == ("Reset")) {
            di1.setText("");
            mi1.setText("");
            yi1.setText("");

            di2.setText("");
            mi2.setText("");
            yi2.setText("");

            di.setText("");
        }
    }
        catch(Exception f)
        {
            JOptionPane.showMessageDialog(null, "Invalid Input");
        }
    }

    public static void main(String[] a) {
        calcu6 b = new calcu6();
        b.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
