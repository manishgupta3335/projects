package sibincalculator;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author manish gupta
 */
import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import javax.swing.*;
public class TimeConverter{
    private JFrame frame;
    private JLabel welcomeLabel;
    private JPanel fromPanel;
    private JLabel centerLabel;
    private JTextField fromField;
    private JComboBox<String> fromBox;
    private JPanel toPanel;
    private JTextField toField;
    private JComboBox<String> toBox;
    private JButton submitButton;
    private JLabel noteLabel;
    private JPanel bottomPanel;
    private final String[] TimeTypes = {"Microseconds", "Milliseconds", "Seconds", "Minutes", "Hours", "Days","Weeks","Years"};
    private final HashMap<String, HashMap<String, Double>> conversions = new HashMap<>();
    public TimeConverter() {
        conversions.put("Microseconds", new HashMap<>());

        conversions.get("Microseconds").put("Microseconds", 1.0);
        conversions.get("Microseconds").put("Milliseconds", 0.001);
        conversions.get("Microseconds").put("Seconds", 1e-6);
        conversions.get("Microseconds").put("Minutes", 1.66667e-8);
        conversions.get("Microseconds").put("Hours", 2.77778e-10);
        conversions.get("Microseconds").put("Days", 1.15741e-11);
        conversions.get("Microseconds").put("Weeks", 1.65344e-12);
        conversions.get("Microseconds").put("Years", 3.17098e-14);

        conversions.put("Milliseconds", new HashMap<>());

        conversions.get("Milliseconds").put("Microseconds", 1000.0);
        conversions.get("Milliseconds").put("Milliseconds", 1.0);
        conversions.get("Milliseconds").put("Seconds", 0.001);
        conversions.get("Milliseconds").put("Minutes", 1.66667e-5);
        conversions.get("Milliseconds").put("Hours", 2.77778e-7);
        conversions.get("Milliseconds").put("Days", 1.15741e-8);
        conversions.get("Milliseconds").put("Weeks", 1.65344e-9);
        conversions.get("Milliseconds").put("Years", 3.17098e-11);

        conversions.put("Seconds", new HashMap<>());

        conversions.get("Seconds").put("Microseconds", 1000000.0);
        conversions.get("Seconds").put("Milliseconds", 1000.0);
        conversions.get("Seconds").put("Seconds", 1.0);
        conversions.get("Seconds").put("Minutes", 0.0166667);
        conversions.get("Seconds").put("Hours", 0.000277778);
        conversions.get("Seconds").put("Days", 1.15741e-5);
        conversions.get("Seconds").put("Weeks", 1.65344e-6);
        conversions.get("Seconds").put("Years", 3.17098e-8);


        conversions.put("Minutes", new HashMap<>());

        conversions.get("Minutes").put("Microseconds", 6e+7);
        conversions.get("Minutes").put("Milliseconds", 60000.0);
        conversions.get("Minutes").put("Seconds", 60.0);
        conversions.get("Minutes").put("Minutes", 1.0);
        conversions.get("Minutes").put("Hours", 0.016667);
        conversions.get("Minutes").put("Days", 0.000694);
        conversions.get("Minutes").put("Weeks", 9.92063e-5);
        conversions.get("Minutes").put("Years", 0.0000254);
        
        
        conversions.put("Hours", new HashMap<>());

        conversions.get("Hours").put("Microseconds", 3.6e+9);
        conversions.get("Hours").put("Milliseconds", 3.6e+6);
        conversions.get("Hours").put("Seconds", 3600.0);
        conversions.get("Hours").put("Minutes", 60.0);
        conversions.get("Hours").put("Hours", 1.0);
        conversions.get("Hours").put("Days", 0.0416667);
        conversions.get("Hours").put("Weeks", 0.00595238);
        conversions.get("Hours").put("Years", 0.000114155);

        conversions.put("Days", new HashMap<>());

        conversions.get("Days").put("Microseconds", 8.64e+10);
        conversions.get("Days").put("Milliseconds", 8.64e+7);
        conversions.get("Days").put("Seconds", 86400.0);
        conversions.get("Days").put("Minutes", 1440.0);
        conversions.get("Days").put("Hours", 24.0);
        conversions.get("Days").put("Days", 1.0);
        conversions.get("Days").put("Weeks", 0.142857);
        conversions.get("Days").put("Years", 0.00273973);
       
        
        conversions.put("Weeks", new HashMap<>()); 
        
        conversions.get("Weeks").put("Microseconds", 6.048e+11);
        conversions.get("Weeks").put("Milliseconds", 6.048e+8);
        conversions.get("Weeks").put("Seconds", 604800.0);
        conversions.get("Weeks").put("Minutes", 10080.0);
        conversions.get("Weeks").put("Hours", 168.0);
        conversions.get("Weeks").put("Days", 7.0);
        conversions.get("Weeks").put("Weeks", 1.0);
        conversions.get("Weeks").put("Years", 0.0191781);
     
    
        
         conversions.put("Years", new HashMap<>());
         
        conversions.get("Years").put("Microseconds", 3.154e+13);
        conversions.get("Years").put("Milliseconds", 3.154e+10);
        conversions.get("Years").put("Seconds", 3.154e+7);
        conversions.get("Years").put("Minutes", 525600.0);
        conversions.get("Years").put("Hours", 8760.0);
        conversions.get("Years").put("Days", 365.0);
        conversions.get("Years").put("Weeks", 52.1429);
        conversions.get("Years").put("Years", 1.0);

       
   
    }
    public static void main(String[] args) {
        new TimeConverter().go();
    }
    public void go() {
        frame = new JFrame("Time Conversions");
        fromPanel = new JPanel();
        centerLabel = new JLabel("Is...");
        fromField = new JTextField(10);
        fromBox = new JComboBox<>(TimeTypes);
        toPanel = new JPanel();
        toBox = new JComboBox<>(TimeTypes);
        toField = new JTextField(10);
        toField.setEnabled(false);
        welcomeLabel = new JLabel("Welcome to the Time converter!");
        submitButton = new JButton("Convert!");
        noteLabel = new JLabel("Note: Rounds to fit the text field.");
        bottomPanel = new JPanel();
        submitButton.addActionListener(new SubmitListener());

        fromPanel.setLayout(new BoxLayout(fromPanel, BoxLayout.X_AXIS));
        fromPanel.add(fromField);
        fromPanel.add(fromBox);

        toPanel.setLayout(new BoxLayout(toPanel, BoxLayout.X_AXIS));
        toPanel.add(toField);
        toPanel.add(toBox);

        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.X_AXIS));
        bottomPanel.add(noteLabel);
        bottomPanel.add(submitButton);

        Font labelFont = new Font("Arial", Font.BOLD, 24);
        welcomeLabel.setFont(labelFont);

        frame.setLayout(new BorderLayout());
        Container window = frame.getContentPane();

        window.add(BorderLayout.NORTH, welcomeLabel);
        window.add(BorderLayout.WEST, fromPanel);
        window.add(BorderLayout.EAST, toPanel);
        window.add(BorderLayout.CENTER, centerLabel);
        window.add(BorderLayout.SOUTH, bottomPanel);

        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
    class SubmitListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try
            {
            Double numToConvert = Double.parseDouble(fromField.getText());
            Double conversionRate = conversions.get(fromBox.getSelectedItem()).get(toBox.getSelectedItem());
            String result = Double.toString(numToConvert * conversionRate);
            int length = result.length();
            if (length > 4) {
                Dimension d = frame.getSize();
                frame.setSize(length + d.width - 16, d.height);
                toField.setColumns(length);
            }
            else {
                toField.setColumns(4);
                frame.pack();
            }
            toField.setText(result);
            frame.revalidate();
        }
            catch(Exception f)
{
   JOptionPane.showMessageDialog(null,"Invalid Input");
}
        }
    }
}