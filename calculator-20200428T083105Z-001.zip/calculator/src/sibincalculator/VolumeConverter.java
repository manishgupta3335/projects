package sibincalculator;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author manish gupta
 */
import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import javax.swing.*;

/**
 *
 * @author manish gupta
 */
public class VolumeConverter 
{
    private JFrame frame;
    private JLabel welcomeLabel;
    private JPanel fromPanel;
    private JLabel centerLabel;
    private JTextField fromField;
    private JComboBox<String> fromBox;
    private JPanel toPanel;
    private JTextField toField;
    private JComboBox<String> toBox;
    private JButton submitButton;
    private JLabel noteLabel;
    private JPanel bottomPanel;
    private final String[] WeightTypes = {"Milliliter", "Liter", "Cubic_Meter", "Teaspoons", "Tablespoons","Fluid_Ounces","Gallons","Cubic_Feet"};
    private final HashMap<String, HashMap<String, Double>> conversions = new HashMap<>();
    public VolumeConverter() {
        conversions.put("Milliliter", new HashMap<>());

        conversions.get("Milliliter").put("Milliliter", 1.0);
        conversions.get("Milliliter").put("Liter", 0.001);
        conversions.get("Milliliter").put("Cubic_Meter", 0.000001);
        conversions.get("Milliliter").put("Teaspoons", 0.202884);
        conversions.get("Milliliter").put("Tablespoons", 0.067628);
        conversions.get("Milliliter").put("Fluid_Ounces", 0.033814);
        conversions.get("Milliliter").put("Gallon", 0.000264172);
        conversions.get("Milliliter").put("Cubic_Feet", 0.00003531467);

         conversions.put("Liter", new HashMap<>());

        conversions.get("Liter").put("Milliliter", 1000.0);
        conversions.get("Liter").put("Liter",1.0 );
        conversions.get("Liter").put("Cubic_Meter", 0.001);
        conversions.get("Liter").put("Teaspoons", 202.884);
        conversions.get("Liter").put("Tablespoons", 67.628);
        conversions.get("Liter").put("Fluid_Ounces", 33.814);
        conversions.get("Liter").put("Gallon",0.264172 );
        conversions.get("Liter").put("Cubic_Feet", 0.0353147);


         conversions.put("Cubic_Meter", new HashMap<>());

        conversions.get("Cubic_Meter").put("Milliliter", 1000000.0);
        conversions.get("Cubic_Meter").put("Liter", 1000.0);
        conversions.get("Cubic_Meter").put("Cubic_Meter", 1.0);
        conversions.get("Cubic_Meter").put("Teaspoons", 202884.0);
        conversions.get("Cubic_Meter").put("Tablespoons", 67628.0);
        conversions.get("Cubic_Meter").put("Fluid_Ounces", 33814.0);
        conversions.get("Cubic_Meter").put("Gallon",264.172 );
        conversions.get("Cubic_Meter").put("Cubic_Feet", 35.3147);


         conversions.put("Teaspoons", new HashMap<>());

        conversions.get("Teaspoons").put("Milliliter",4.92892);
        conversions.get("Teaspoons").put("Liter", 0.00492892);
        conversions.get("Teaspoons").put("Cubic_Meter", 0.000004928922);
        conversions.get("Teaspoons").put("Teaspoons", 1.0);
        conversions.get("Teaspoons").put("Tablespoons", 0.33333333);
        conversions.get("Teaspoons").put("Fluid_Ounces", 0.166667);
        conversions.get("Teaspoons").put("Gallon",0.00130208 );
        conversions.get("Teaspoons").put("Cubic_Feet", 0.000174063);

       conversions.put("Tablespoons", new HashMap<>());

        conversions.get("Tablespoons").put("Milliliter", 14.7868);
        conversions.get("Tablespoons").put("Liter", 0.0147868);
        conversions.get("Tablespoons").put("Cubic_Meter", 0.000015);
        conversions.get("Tablespoons").put("Teaspoons", 3.0);
        conversions.get("Tablespoons").put("Tablespoons", 1.0);
        conversions.get("Tablespoons").put("Fluid_Ounces", 0.5);
        conversions.get("Tablespoons").put("Gallon", 0.00390625 );
        conversions.get("Tablespoons").put("Cubic_Feet", 0.00052219);

         conversions.put("Fluid_Ounces", new HashMap<>());

        conversions.get("Fluid_Ounces").put("Milliliter", 29.5735);
        conversions.get("Fluid_Ounces").put("Liter", 0.0295735);
        conversions.get("Fluid_Ounces").put("Cubic_Meter", 0.00002957353);
        conversions.get("Fluid_Ounces").put("Teaspoons", 6.0);
        conversions.get("Fluid_Ounces").put("Tablespoons", 2.0);
        conversions.get("Fluid_Ounces").put("Fluid_Ounces", 1.0);
        conversions.get("Fluid_Ounces").put("Gallon",0.0078125 );
        conversions.get("Fluid_Ounces").put("Cubic_Feet", 0.00104438);

        conversions.put("Gallon", new HashMap<>());

        conversions.get("Gallon").put("Milliliter", 3785.41);
        conversions.get("Gallon").put("Liter", 3.78541);
        conversions.get("Gallon").put("Cubic_Meter", 0.00378541);
        conversions.get("Gallon").put("Teaspoons", 768.0);
        conversions.get("Gallon").put("Tablespoons", 256.0);
        conversions.get("Gallon").put("Fluid_Ounces",128.0);
        conversions.get("Gallon").put("Gallon", 1.0 );
        conversions.get("Gallon").put("Cubic_Feet", 0.133681);

        
            conversions.put("Cubic_Feet", new HashMap<>());

        conversions.get("Cubic_Feet").put("Milliliter", 28316.8);
        conversions.get("Cubic_Feet").put("Liter", 28.3168);
        conversions.get("Cubic_Feet").put("Cubic_Meter", 0.0283168);
        conversions.get("Cubic_Feet").put("Teaspoons", 5745.04);
        conversions.get("Cubic_Feet").put("Tablespoons", 1915.01);
        conversions.get("Cubic_Feet").put("Fluid_Ounces", 957.506);
        conversions.get("Cubic_Feet").put("Gallon", 7.48052 );
        conversions.get("Cubic_Feet").put("Cubic_Feet", 1.0);
    }
    public static void main(String[] args) {
        new VolumeConverter().go();
    }
    public void go() {
        frame = new JFrame("Volume Conversions");
        fromPanel = new JPanel();
        centerLabel = new JLabel("..To..");
        fromField = new JTextField(10);
        fromBox = new JComboBox<>(WeightTypes);
        toPanel = new JPanel();
        toBox = new JComboBox<>(WeightTypes);
        toField = new JTextField(10);
        toField.setEnabled(false);
        welcomeLabel = new JLabel("Welcome to the Volume converter!");
        submitButton = new JButton("Convert!");
        noteLabel = new JLabel("Note: Rounds to fit the text field.");
        bottomPanel = new JPanel();
        submitButton.addActionListener(new SubmitListener());

        fromPanel.setLayout(new BoxLayout(fromPanel, BoxLayout.X_AXIS));
        fromPanel.add(fromField);
        fromPanel.add(fromBox);

        toPanel.setLayout(new BoxLayout(toPanel, BoxLayout.X_AXIS));
        toPanel.add(toField);
        toPanel.add(toBox);

        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.X_AXIS));
        bottomPanel.add(noteLabel);
        bottomPanel.add(submitButton);

        Font labelFont = new Font("Arial", Font.BOLD, 24);
        welcomeLabel.setFont(labelFont);

        frame.setLayout(new BorderLayout());
        Container window = frame.getContentPane();

        window.add(BorderLayout.NORTH, welcomeLabel);
        window.add(BorderLayout.WEST, fromPanel);
        window.add(BorderLayout.EAST, toPanel);
        window.add(BorderLayout.CENTER, centerLabel);
        window.add(BorderLayout.SOUTH, bottomPanel);

        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
    class SubmitListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try
            {
            Double numToConvert = Double.parseDouble(fromField.getText());
            Double conversionRate = conversions.get(fromBox.getSelectedItem()).get(toBox.getSelectedItem());
            String result = Double.toString(numToConvert * conversionRate);
            int length = result.length();
            if (length > 4) {
                Dimension d = frame.getSize();
                frame.setSize(length + d.width - 16, d.height);
                toField.setColumns(length);
            }
            else {
                toField.setColumns(4);
                frame.pack();
            }
            toField.setText(result);
            frame.revalidate();
            }
            catch(Exception f)
{
   JOptionPane.showMessageDialog(null,"Invalid Input");
}
        }

    }
}