package sibincalculator;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author manish gupta
 */
import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import javax.swing.*;
public class SpeedConverter{
    private JFrame frame;
    private JLabel welcomeLabel;
    private JPanel fromPanel;
    private JLabel centerLabel;
    private JTextField fromField;
    private JComboBox<String> fromBox;
    private JPanel toPanel;
    private JTextField toField;
    private JComboBox<String> toBox;
    private JButton submitButton;
    private JLabel noteLabel;
    private JPanel bottomPanel;
    private final String[] SpeedTypes = {"Centimeters/Second","Meters/Second", "Kilometer/Second","Feet/Second",  "Miles/Hour","Knots","Mach"};
    private final HashMap<String, HashMap<String, Double>> conversions = new HashMap<>();
    public SpeedConverter() {
        conversions.put("Centimeters/Second", new HashMap<>());

        conversions.get("Centimeters/Second").put("Centimeters/Second", 1.0);
        conversions.get("Centimeters/Second").put("Meters/Second", 0.01);
        conversions.get("Centimeters/Second").put("Kilometer/Second", 1e-5);
        conversions.get("Centimeters/Second").put("Feet/Second", 0.0328084);
        conversions.get("Centimeters/Second").put("Miles/Hour", 0.0223694);
        conversions.get("Centimeters/Second").put("Knots", 0.0194384);
        conversions.get("Centimeters/Second").put("Mach", 2.91545e-5);

        conversions.put("Meters/Second", new HashMap<>());

        conversions.get("Meters/Second").put("Centimeters/Second", 100.0);
        conversions.get("Meters/Second").put("Meters/Second", 1.0);
        conversions.get("Meters/Second").put("Kilometer/Second", 0.001);
        conversions.get("Meters/Second").put("Feet/Second", 3.28084);
        conversions.get("Meters/Second").put("Miles/Hour", 0.000621371);
        conversions.get("Meters/Second").put("Knots", 1.94384);
        conversions.get("Meters/Second").put("Mach", 0.00291545);

        conversions.put("Kilometer/Second", new HashMap<>());

        conversions.get("Kilometer/Second").put("Centimeters/Second", 100000.0);
        conversions.get("Kilometer/Second").put("Meters/Second", 1000.0);
        conversions.get("Kilometer/Second").put("Kilometer/Second", 1.0);
        conversions.get("Kilometer/Second").put("Feet/Second", 3280.84);
        conversions.get("Kilometer/Second").put("Miles/Hour", 2236.94);
        conversions.get("Kilometer/Second").put("Knots", 1943.84);
        conversions.get("Kilometer/Second").put("Mach", 2.91545);
        
        conversions.put("Feet/Second", new HashMap<>());

        conversions.get("Feet/Second").put("Centimeters/Second", 30.48);
        conversions.get("Feet/Second").put("Meters/Second", 0.3048);
        conversions.get("Feet/Second").put("Kilometer/Second", 0.0003048);
        conversions.get("Feet/Second").put("Feet/Second", 1.0);
        conversions.get("Feet/Second").put("Miles/Hour", 0.681818);
        conversions.get("Feet/Second").put("Knots", 0.592484);
        conversions.get("Feet/Second").put("Mach", 0.00088863);

      

        conversions.put("Miles/Hour", new HashMap<>());

        conversions.get("Miles/Hour").put("Centimeters/Second", 44.704);
        conversions.get("Miles/Hour").put("Meters/Second", 0.44704);
        conversions.get("Miles/Hour").put("Kilometer/Second", 0.00044704);
        conversions.get("Miles/Hour").put("Feet/Second", 1.46667);
        conversions.get("Miles/Hour").put("Miles/Hour", 1.0);
        conversions.get("Miles/Hour").put("Knots", 0.868976);
        conversions.get("Miles/Hour").put("Mach", 0.00130332);
        
         conversions.put("Knots", new HashMap<>());

        conversions.get("Knots").put("Centimeters/Second", 51.4444);
        conversions.get("Knots").put("Meters/Second", 0.514444);
        conversions.get("Knots").put("Kilometer/Second", 0.000514444);
        conversions.get("Knots").put("Feet/Second", 1.68781);
        conversions.get("Knots").put("Miles/Hour", 1.15078);
        conversions.get("Knots").put("Knots", 1.0);
        conversions.get("Knots").put("Mach", 0.00149984);

       
        
        conversions.put("Mach", new HashMap<>());

        conversions.get("Mach").put("Centimeters/Second", 34300.0);
        conversions.get("Mach").put("Meters/Second", 343.0);
        conversions.get("Mach").put("Kilometer/Second", 0.343);
        conversions.get("Mach").put("Feet/Second", 1125.33);
        conversions.get("Mach").put("Miles/Hour", 767.269);
        conversions.get("Mach").put("Knots", 666.739);
        conversions.get("Mach").put("Mach", 1.0);
    }
    public static void main(String[] args) {
        new SpeedConverter().go();
    }
    public void go() {
        frame = new JFrame("Speed Conversions");
        fromPanel = new JPanel();
        centerLabel = new JLabel("..To..");
        fromField = new JTextField(10);
        fromBox = new JComboBox<>(SpeedTypes);
        toPanel = new JPanel();
        toBox = new JComboBox<>(SpeedTypes);
        toField = new JTextField(10);
        toField.setEnabled(false);
        welcomeLabel = new JLabel("Welcome to the Speed converter!");
        submitButton = new JButton("Convert!");
        noteLabel = new JLabel("Note: Rounds to fit the text field.");
        bottomPanel = new JPanel();
        submitButton.addActionListener(new SubmitListener());

        fromPanel.setLayout(new BoxLayout(fromPanel, BoxLayout.X_AXIS));
        fromPanel.add(fromField);
        fromPanel.add(fromBox);

        toPanel.setLayout(new BoxLayout(toPanel, BoxLayout.X_AXIS));
        toPanel.add(toField);
        toPanel.add(toBox);

        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.X_AXIS));
        bottomPanel.add(noteLabel);
        bottomPanel.add(submitButton);

        Font labelFont = new Font("Arial", Font.BOLD, 24);
        welcomeLabel.setFont(labelFont);

        frame.setLayout(new BorderLayout());
        Container window = frame.getContentPane();

        window.add(BorderLayout.NORTH, welcomeLabel);
        window.add(BorderLayout.WEST, fromPanel);
        window.add(BorderLayout.EAST, toPanel);
        window.add(BorderLayout.CENTER, centerLabel);
        window.add(BorderLayout.SOUTH, bottomPanel);

        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
    class SubmitListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try
            {
            Double numToConvert = Double.parseDouble(fromField.getText());
            Double conversionRate = conversions.get(fromBox.getSelectedItem()).get(toBox.getSelectedItem());
            String result = Double.toString(numToConvert * conversionRate);
            int length = result.length();
            if (length > 4) {
                Dimension d = frame.getSize();
                frame.setSize(length + d.width - 16, d.height);
                toField.setColumns(length);
            }
            else {
                toField.setColumns(4);
                frame.pack();
            }
            toField.setText(result);
            frame.revalidate();
            }
            catch(Exception f)
{
   JOptionPane.showMessageDialog(null,"Invalid Input");
}
        }

    }
}