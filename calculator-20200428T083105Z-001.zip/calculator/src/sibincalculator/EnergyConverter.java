package sibincalculator;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author manish gupta
 */
import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import javax.swing.*;
public class EnergyConverter{
    private JFrame frame;
    private JLabel welcomeLabel;
    private JPanel fromPanel;
    private JLabel centerLabel;
    private JTextField fromField;
    private JComboBox<String> fromBox;
    private JPanel toPanel;
    private JTextField toField;
    private JComboBox<String> toBox;
    private JButton submitButton;
    private JLabel noteLabel;
    private JPanel bottomPanel;
    private final String[] energyTypes = {"Electron_Volt", "Joules", "Kilojoules", "Thermal_Calories", "Food_Calories", "Food_Pound"};
    private final HashMap<String, HashMap<String, Double>> conversions = new HashMap<>();
    public EnergyConverter() {
        conversions.put("Electron_Volt", new HashMap<>());

        conversions.get("Electron_Volt").put("Electron_Volt", 1.0);
        conversions.get("Electron_Volt").put("Joules", 1.602176565e-19);
        conversions.get("Electron_Volt").put("Kilojoules", 1.60218e-22);
        conversions.get("Electron_Volt").put("Thermal_Calories", 3.829294e-20 );
        conversions.get("Electron_Volt").put("Food_Calories", 3.829294e-23);
        conversions.get("Electron_Volt").put("Food_Pound", 1.181705e-19);
       

        conversions.put("Joules", new HashMap<>());

         conversions.get("Joules").put("Electron_Volt",6.242e+18 );
        conversions.get("Joules").put("Joules", 1.0);
        conversions.get("Joules").put("Kilojoules", 0.001);
        conversions.get("Joules").put("Thermal_Calories", 0.239006);
        conversions.get("Joules").put("Food_Calories", 0.737562);
        conversions.get("Joules").put("Food_Pound", 0.737562);

        conversions.put("Kilojoules", new HashMap<>());

        conversions.get("Kilojoules").put("Electron_Volt", 6.242e+21);
        conversions.get("Kilojoules").put("Joules", 1000.0);
        conversions.get("Kilojoules").put("Kilojoules", 1.0);
        conversions.get("Kilojoules").put("Thermal_Calories", 239.0057);
        conversions.get("Kilojoules").put("Food_Calories", 0.23900573614);
        conversions.get("Kilojoules").put("Food_Pound", 737.5621493);

        conversions.put("Tharmal_Calories", new HashMap<>());
        
         conversions.get("Tharmal_Calories").put("Electron_Volt", 2.6131952590564e+19);
        conversions.get("Tharmal_Calories").put("Joules", 4.184);
        conversions.get("Tharmal_Calories").put("Kilojoules", 0.004184);
        conversions.get("Tharmal_Calories").put("Thermal_Calories", 1.0);
        conversions.get("Tharmal_Calories").put("Food_Calories", 0.001);
        conversions.get("Tharmal_Calories").put("Food_Pound", 3.08596);

        

        conversions.put("Food_Calories", new HashMap<>());
        
        conversions.get("Food_Calories").put("Electron_Volt", 1.0);
        conversions.get("Food_Calories").put("Joules", 4184.0);
        conversions.get("Food_Calories").put("Kilojoules", 4.184);
        conversions.get("Food_Calories").put("Thermal_Calories", 1000.0);
        conversions.get("Food_Calories").put("Food_Calories", 1.0);
        conversions.get("Food_Calories").put("Food_Pound", 3085.96);

        conversions.put("Food_Pound", new HashMap<>());
        
        conversions.get("Food_Pound").put("Electron_Volt", 8.462350e+18);
        conversions.get("Food_Pound").put("Joules", 1.355818);
        conversions.get("Food_Pound").put("Kilojoules",0.001355818 );
        conversions.get("Food_Pound").put("Thermal_Calories", 0.324048);
        conversions.get("Food_Pound").put("Food_Calories", 0.000324048);
        conversions.get("Food_Pound").put("Food_Pound", 1.0);

     
    }
    public static void main(String[] args) {
        new EnergyConverter().go();
    }
    public void go() {
        frame = new JFrame("Energy Conversions");
        fromPanel = new JPanel();
        centerLabel = new JLabel("..To..");
        fromField = new JTextField(10);
        fromBox = new JComboBox<>(energyTypes);
        toPanel = new JPanel();
        toBox = new JComboBox<>(energyTypes);
        toField = new JTextField(10);
        toField.setEnabled(false);
        welcomeLabel = new JLabel("Welcome to the Energy converter!");
        submitButton = new JButton("Convert!");
        noteLabel = new JLabel("Note: Rounds to fit the text field.");
        bottomPanel = new JPanel();
        submitButton.addActionListener(new SubmitListener());

        fromPanel.setLayout(new BoxLayout(fromPanel, BoxLayout.X_AXIS));
        fromPanel.add(fromField);
        fromPanel.add(fromBox);

        toPanel.setLayout(new BoxLayout(toPanel, BoxLayout.X_AXIS));
        toPanel.add(toField);
        toPanel.add(toBox);

        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.X_AXIS));
        bottomPanel.add(noteLabel);
        bottomPanel.add(submitButton);

        Font labelFont = new Font("Arial", Font.BOLD, 24);
        welcomeLabel.setFont(labelFont);

        frame.setLayout(new BorderLayout());
        Container window = frame.getContentPane();

        window.add(BorderLayout.NORTH, welcomeLabel);
        window.add(BorderLayout.WEST, fromPanel);
        window.add(BorderLayout.EAST, toPanel);
        window.add(BorderLayout.CENTER, centerLabel);
        window.add(BorderLayout.SOUTH, bottomPanel);

        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
    class SubmitListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try
            {
            Double numToConvert = Double.parseDouble(fromField.getText());
            Double conversionRate = conversions.get(fromBox.getSelectedItem()).get(toBox.getSelectedItem());
            String result = Double.toString(numToConvert * conversionRate);
            int length = result.length();
            if (length > 4) {
                Dimension d = frame.getSize();
                frame.setSize(length + d.width - 16, d.height);
                toField.setColumns(length);
            }
            else {
                toField.setColumns(4);
                frame.pack();
            }
            toField.setText(result);
            frame.revalidate();
            }
            catch(Exception f)
{
   JOptionPane.showMessageDialog(null,"Invalid Input");
}
        }

    }
}