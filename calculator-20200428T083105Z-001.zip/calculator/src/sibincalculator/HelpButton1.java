/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sibincalculator;
import javax.swing.JOptionPane;

/**
 *
 * @author manish gupta
 */
class HelpButton1 {
    public static void main(String args[])
    {
        JOptionPane.showMessageDialog(null,"ADVANCE CALCULATOR \nDeveloper                      Manish Gupta\nVersion                          1.0\n\nOperation Performed   :\n1.You can perform scientific as well as simple calculation.\n2.You can convert one unit of value to another unit.\n3.You can access certain mathematical functions.\n4.You can calculate the interest/EMI\n5.You can calculate the difference between the two days\n6.You can claculate the BMI/BSR");
    }
}
