package sibincalculator;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author manish gupta
 */
import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import javax.swing.*;
public class LengthConverter extends javax.swing.JFrame{
    private JFrame frame;
    private JLabel welcomeLabel;
    private JPanel fromPanel;
    private JLabel centerLabel;
    private JTextField fromField;
    private JComboBox<String> fromBox;
    private JPanel toPanel;
    private JTextField toField;
    private JComboBox<String> toBox;
    private JButton submitButton;
    private JButton Close;
    private JLabel noteLabel;
    private JPanel bottomPanel;
    private final String[] lengthTypes = {"Inches", "Centimeters", "Feet", "Yards", "Meters", "Millimeters","Kilometer"};
    private final HashMap<String, HashMap<String, Double>> conversions = new HashMap<>();
    public LengthConverter() {
        conversions.put("Inches", new HashMap<>());

        conversions.get("Inches").put("Inches", 1.0);
        conversions.get("Inches").put("Centimeters", 2.54);
        conversions.get("Inches").put("Feet", 0.0833333);
        conversions.get("Inches").put("Yards", 0.0277778);
        conversions.get("Inches").put("Meters", 0.0254);
        conversions.get("Inches").put("Millimeters", 25.4);
        conversions.get("Inches").put("Kilometer", 0.0000254);

        conversions.put("Centimeters", new HashMap<>());

        conversions.get("Centimeters").put("Inches", 0.393701);
        conversions.get("Centimeters").put("Centimeters", 1.0);
        conversions.get("Centimeters").put("Feet", 0.0328084);
        conversions.get("Centimeters").put("Yards", 0.0109361);
        conversions.get("Centimeters").put("Meters", 0.01);
        conversions.get("Centimeters").put("Millimeters", 10.0);
        conversions.get("Centimeters").put("Kilometer", 0.00001);

        conversions.put("Feet", new HashMap<>());

        conversions.get("Feet").put("Inches", 12.0);
        conversions.get("Feet").put("Centimeters", 30.48);
        conversions.get("Feet").put("Feet", 1.0);
        conversions.get("Feet").put("Yards", 0.3333333);
        conversions.get("Feet").put("Meters", 0.3048);
        conversions.get("Feet").put("Millimeters", 304.8);
        conversions.get("Feet").put("Kilometer", 0.0003048);

        conversions.put("Yards", new HashMap<>());

        conversions.get("Yards").put("Inches", 36.0);
        conversions.get("Yards").put("Centimeters", 91.44);
        conversions.get("Yards").put("Feet", 3.0);
        conversions.get("Yards").put("Yards", 1.0);
        conversions.get("Yards").put("Meters", 0.9144);
        conversions.get("Yards").put("Millimeters", 914.4);
        conversions.get("Yards").put("Kilometer", 0.0009144);

        conversions.put("Meters", new HashMap<>());

        conversions.get("Meters").put("Inches", 39.3701);
        conversions.get("Meters").put("Centimeters", 100.0);
        conversions.get("Meters").put("Feet", 3.28084);
        conversions.get("Meters").put("Yards", 1.09361);
        conversions.get("Meters").put("Meters", 1.0);
        conversions.get("Meters").put("Millimeters", 1000.0);
        conversions.get("Meters").put("Kilometer", 0.001);

        conversions.put("Millimeters", new HashMap<>());

        conversions.get("Millimeters").put("Inches", 0.0393701);
        conversions.get("Millimeters").put("Centimeters", 0.1);
        conversions.get("Millimeters").put("Feet", 0.00328084);
        conversions.get("Millimeters").put("Yards", 0.00109361);
        conversions.get("Millimeters").put("Meters", 0.001);
        conversions.get("Millimeters").put("Millimeters", 1.0);
        conversions.get("Millimeters").put("Kilometer", 0.000001);
        
         conversions.put("Kilometer", new HashMap<>());

        conversions.get("Kilometer").put("Inches", 39370.1);
        conversions.get("Kilometer").put("Centimeters", 100000.0);
        conversions.get("Kilometer").put("Feet", 3280.84);
        conversions.get("Kilometer").put("Yards", 1093.61);
        conversions.get("Kilometer").put("Meters", 1000.0);
        conversions.get("Kilometer").put("Millimeters", 1000000.0);
        conversions.get("Kilometer").put("Kilometer", 1.0);
    }
    public static void main(String[] args) {
        new LengthConverter().go();
    }
    public void go() {
        frame = new JFrame("Length Conversions");
        fromPanel = new JPanel();
        centerLabel = new JLabel("..To..");
        fromField = new JTextField(10);
        fromBox = new JComboBox<>(lengthTypes);
        toPanel = new JPanel();
        toBox = new JComboBox<>(lengthTypes);
        toField = new JTextField(10);
        toField.setEnabled(false);
        welcomeLabel = new JLabel("Welcome to the length converter!");
        submitButton = new JButton("Convert!");
        Close = new JButton("Close");
        noteLabel = new JLabel("Note: Rounds to fit the text field.");
        bottomPanel = new JPanel();
        submitButton.addActionListener(new SubmitListener());
        Close.addActionListener(new CloseListener());

        fromPanel.setLayout(new BoxLayout(fromPanel, BoxLayout.X_AXIS));
        fromPanel.add(fromField);
        fromPanel.add(fromBox);

        toPanel.setLayout(new BoxLayout(toPanel, BoxLayout.X_AXIS));
        toPanel.add(toField);
        toPanel.add(toBox);

        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.X_AXIS));
        bottomPanel.add(noteLabel);
        bottomPanel.add(submitButton);
        bottomPanel.add(Close);
        
        

        Font labelFont = new Font("Arial", Font.BOLD, 24);
        welcomeLabel.setFont(labelFont);

        frame.setLayout(new BorderLayout());
        Container window = frame.getContentPane();

        window.add(BorderLayout.NORTH, welcomeLabel);
        window.add(BorderLayout.WEST, fromPanel);
        window.add(BorderLayout.EAST, toPanel);
        window.add(BorderLayout.CENTER, centerLabel);
        window.add(BorderLayout.SOUTH, bottomPanel);

        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
    class SubmitListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try
            {
            Double numToConvert = Double.parseDouble(fromField.getText());
            Double conversionRate = conversions.get(fromBox.getSelectedItem()).get(toBox.getSelectedItem());
            String result = Double.toString(numToConvert * conversionRate);
            int length = result.length();
            if (length > 4) {
                Dimension d = frame.getSize();
                frame.setSize(length + d.width - 16, d.height);
                toField.setColumns(length);
            }
            else {
                toField.setColumns(4);
                frame.pack();
            }
            toField.setText(result);
            frame.revalidate();
        }
        
        catch(Exception f)
{
   JOptionPane.showMessageDialog(null,"Invalid Input");
}
    }
    }
    class CloseListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e)
        {
          dispose();
        }
    }
}