package sibincalculator;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author manish gupta
 */
import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import javax.swing.*;
public class PowerConverter{
    private JFrame frame;
    private JLabel welcomeLabel;
    private JPanel fromPanel;
    private JLabel centerLabel;
    private JTextField fromField;
    private JComboBox<String> fromBox;
    private JPanel toPanel;
    private JTextField toField;
    private JComboBox<String> toBox;
    private JButton submitButton;
    private JLabel noteLabel;
    private JPanel bottomPanel;
    private final String[] PowerTypes = {"Watts", "Kilowatts", "Horsepower(us)", "Foot_Pound/Minute", "BTUs/Minute"};
    private final HashMap<String, HashMap<String, Double>> conversions = new HashMap<>();
    public PowerConverter() {
        conversions.put("Watts", new HashMap<>());

        conversions.get("Watts").put("Watts", 1.0);
        conversions.get("Watts").put("Kilowatts", 0.001);
        conversions.get("Watts").put("Horsepower(us)", 0.001341);
        conversions.get("Watts").put("Foot_Pound/Minute", 44.25373);
        conversions.get("Watts").put("BTUs/Minute", 0.056869);

        conversions.put("Kilowatts", new HashMap<>());

        conversions.get("Kilowatts").put("Watts", 1000.0);
        conversions.get("Kilowatts").put("Kilowatts", 1.0);
        conversions.get("Kilowatts").put("Horsepower(us)", 1.341022);
        conversions.get("Kilowatts").put("Foot_Pound/Minute", 44253.73);
        conversions.get("Kilowatts").put("BTUs/Minute", 56.86902);


        conversions.put("Horsepower(us)", new HashMap<>());
        
        conversions.get("Horsepower(us)").put("Watts", 745.7);
        conversions.get("Horsepower(us)").put("Kilowatts", 0.7457);
        conversions.get("Horsepower(us)").put("Horsepower(us)", 1.0);
        conversions.get("Horsepower(us)").put("Foot_Pound/Minute", 33000.0);
        conversions.get("Horsepower(us)").put("BTUs/Minute", 42.40722);

     

        conversions.put("Foot_Pound/Minute", new HashMap<>());
        
        conversions.get("Foot_Pound/Minute").put("Watts", 0.0225969658);
        conversions.get("Foot_Pound/Minute").put("Kilowatts", 0.000023);
        conversions.get("Foot_Pound/Minute").put("Horsepower(us)", 0.0000303);
        conversions.get("Foot_Pound/Minute").put("Foot_Pound/Minute", 1.0);
        conversions.get("Foot_Pound/Minute").put("BTUs/Minute", 0.00128507);

 

        conversions.put("BTUs/Minute", new HashMap<>());

        conversions.get("BTUs/Minute").put("Watts", 17.5842642);
        conversions.get("BTUs/Minute").put("Kilowatts", 0.0175842642);
        conversions.get("BTUs/Minute").put("Horsepower(us)", 0.0235808867 );
        conversions.get("BTUs/Minute").put("Foot_Pound/Minute", 778.1694);
        conversions.get("BTUs/Minute").put("BTUs/Minute", 1.0);

 
    }
    public static void main(String[] args) {
        new PowerConverter().go();
    }
    public void go() {
        frame = new JFrame("Power Conversions");
        fromPanel = new JPanel();
        centerLabel = new JLabel("..To..");
        fromField = new JTextField(10);
        fromBox = new JComboBox<>(PowerTypes);
        toPanel = new JPanel();
        toBox = new JComboBox<>(PowerTypes);
        toField = new JTextField(10);
        toField.setEnabled(false);
        welcomeLabel = new JLabel("Welcome to the Power converter!");
        submitButton = new JButton("Convert!");
        noteLabel = new JLabel("Note: Rounds to fit the text field.");
        bottomPanel = new JPanel();
        submitButton.addActionListener(new SubmitListener());

        fromPanel.setLayout(new BoxLayout(fromPanel, BoxLayout.X_AXIS));
        fromPanel.add(fromField);
        fromPanel.add(fromBox);

        toPanel.setLayout(new BoxLayout(toPanel, BoxLayout.X_AXIS));
        toPanel.add(toField);
        toPanel.add(toBox);

        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.X_AXIS));
        bottomPanel.add(noteLabel);
        bottomPanel.add(submitButton);

        Font labelFont = new Font("Arial", Font.BOLD, 24);
        welcomeLabel.setFont(labelFont);

        frame.setLayout(new BorderLayout());
        Container window = frame.getContentPane();

        window.add(BorderLayout.NORTH, welcomeLabel);
        window.add(BorderLayout.WEST, fromPanel);
        window.add(BorderLayout.EAST, toPanel);
        window.add(BorderLayout.CENTER, centerLabel);
        window.add(BorderLayout.SOUTH, bottomPanel);

        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
    class SubmitListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try
            {
            Double numToConvert = Double.parseDouble(fromField.getText());
            Double conversionRate = conversions.get(fromBox.getSelectedItem()).get(toBox.getSelectedItem());
            String result = Double.toString(numToConvert * conversionRate);
            int length = result.length();
            if (length > 4) {
                Dimension d = frame.getSize();
                frame.setSize(length + d.width - 16, d.height);
                toField.setColumns(length);
            }
            else {
                toField.setColumns(4);
                frame.pack();
            }
            toField.setText(result);
            frame.revalidate();
            }
catch(Exception f)
{
   JOptionPane.showMessageDialog(null,"Invalid Input");
}        }

    }
}