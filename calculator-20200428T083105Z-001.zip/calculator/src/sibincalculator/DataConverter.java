package sibincalculator;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author manish gupta
 */
import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import javax.swing.*;
public class DataConverter{
    private JFrame frame;
    private JLabel welcomeLabel;
    private JPanel fromPanel;
    private JLabel centerLabel;
    private JTextField fromField;
    private JComboBox<String> fromBox;
    private JPanel toPanel;
    private JTextField toField;
    private JComboBox<String> toBox;
    private JButton submitButton;
    private JLabel noteLabel;
    private JPanel bottomPanel;
    private final String[] DataTypes = {"Nibble", "Bits", "Bytes", "Kilobyte", "Megabyte", "Gigabyte","Terabyte","Petabyte","Exabyte","Zettabyte","Yottabyte"};
    private final HashMap<String, HashMap<String, Double>> conversions = new HashMap<>();
    public DataConverter() {
        conversions.put("Nibble", new HashMap<>());

        conversions.get("Nibble").put("Nibble", 1.0);
        conversions.get("Nibble").put("Bits", 4.0);
        conversions.get("Nibble").put("Bytes", 0.5);
        conversions.get("Nibble").put("Kilobyte", 0.0005);
        conversions.get("Nibble").put("Megabyte", 5e-7);
        conversions.get("Nibble").put("Gigabyte", 5e-10);
        conversions.get("Nibble").put("Terabyte", 5e-13);
        conversions.get("Nibble").put("Petabyte", 5e-16);
        conversions.get("Nibble").put("Exabyte", 5e-19);
        conversions.get("Nibble").put("Zettabyte", 5e-22);
        conversions.get("Nibble").put("Yottabyte", 5e-25);
        
        conversions.put("Bits", new HashMap<>());

        conversions.get("Bits").put("Nibble", 0.25);
        conversions.get("Bits").put("Bits", 1.0);
        conversions.get("Bits").put("Bytes", 0.125);
        conversions.get("Bits").put("Kilobyte", 0.000125);
        conversions.get("Bits").put("Megabyte", 1.25e-7);
        conversions.get("Bits").put("Gigabyte", 1.25e-10);
        conversions.get("Bits").put("Terabyte", 1.25e-13);
        conversions.get("Bits").put("Petabyte", 1.25e-16);
        conversions.get("Bits").put("Exabyte", 1.25e-19);
        conversions.get("Bits").put("Zettabyte", 1.25e-22);
        conversions.get("Bits").put("Yottabyte", 1.25e-25);

        conversions.put("Byte", new HashMap<>());

        conversions.get("Byte").put("Nibble", 2.0);
        conversions.get("Byte").put("Bits", 8.0);
        conversions.get("Byte").put("Bytes", 1.0);
        conversions.get("Byte").put("Kilobyte", 0.001);
        conversions.get("Byte").put("Megabyte", 0.000001);
        conversions.get("Byte").put("Gigabyte", 1e-9);
        conversions.get("Byte").put("Terabyte", 1e-12);
        conversions.get("Byte").put("Petabyte", 1.000000e-15);
        conversions.get("Byte").put("Exabyte", 1e-18);
        conversions.get("Byte").put("Zettabyte", 1.000000e-21);
        conversions.get("Byte").put("Yottabyte", 1e-24);

        conversions.put("Kilobyte", new HashMap<>());

        conversions.get("Kilobyte").put("Nibble", 2000.0 );
        conversions.get("Kilobyte").put("Bits", 8000.0);
        conversions.get("Kilobyte").put("Bytes", 1000.0);
        conversions.get("Kilobyte").put("Kilobyte", 1.0);
        conversions.get("Kilobyte").put("Megabyte", 0.001);
        conversions.get("Kilobyte").put("Gigabyte", 1e-6);
        conversions.get("Kilobyte").put("Terabyte", 1e-9);
        conversions.get("Kilobyte").put("Petabyte", 1e-12);
        conversions.get("Kilobyte").put("Exabyte", 1e-15);
        conversions.get("Kilobyte").put("Zettabyte", 1e-18);
        conversions.get("Kilobyte").put("Yottabyte", 1e-21);
   
        conversions.put("Megabyte", new HashMap<>());

        conversions.get("Megabyte").put("Nibble", 2e+6);
        conversions.get("Megabyte").put("Bits", 8e+6);
        conversions.get("Megabyte").put("Bytes", 1000000.0);
        conversions.get("Megabyte").put("Kilobyte", 1000.0);
        conversions.get("Megabyte").put("Megabyte", 1.0);
        conversions.get("Megabyte").put("Gigabyte", 0.001);
        conversions.get("Megabyte").put("Terabyte", 1e-6);
        conversions.get("Megabyte").put("Petabyte", 1e-9);
        conversions.get("Megabyte").put("Exabyte", 1e-12);
        conversions.get("Megabyte").put("Zettabyte", 1e-15);
        conversions.get("Megabyte").put("Yottabyte", 1e-18);

        conversions.put("Gigabyte", new HashMap<>());

        conversions.get("Gigabyte").put("Nibble", 2e+9);
        conversions.get("Gigabyte").put("Bits", 8e+9);
        conversions.get("Gigabyte").put("Bytes", 1e+9);
        conversions.get("Gigabyte").put("Kilobyte", 1000000.0);
        conversions.get("Gigabyte").put("Megabyte", 1000.0);
        conversions.get("Gigabyte").put("Gigabyte", 1.0);
        conversions.get("Gigabyte").put("Terabyte", 0.001);
        conversions.get("Gigabyte").put("Petabyte", 1e-6);
        conversions.get("Gigabyte").put("Exabyte", 1e-9);
        conversions.get("Gigabyte").put("Zettabyte", 1e-12);
        conversions.get("Gigabyte").put("Yottabyte", 0.000000e-15);

        conversions.put("Terabyte", new HashMap<>());

        conversions.get("Terabyte").put("Nibble", 2e+12);
        conversions.get("Terabyte").put("Bits", 8e+12);
        conversions.get("Terabyte").put("Bytes", 1e+12);
        conversions.get("Terabyte").put("Kilobyte", 1e+9);
        conversions.get("Terabyte").put("Megabyte", 1000000.0);
        conversions.get("Terabyte").put("Gigabyte", 1000.0);
        conversions.get("Terabyte").put("Terabyte", 1.0);
        conversions.get("Terabyte").put("Petabyte", 0.001);
        conversions.get("Terabyte").put("Exabyte", 1e-6);
        conversions.get("Terabyte").put("Zettabyte", 1e-9);
        conversions.get("Terabyte").put("Yottabyte", 1e-12);
        
         conversions.put("Petabyte", new HashMap<>());

        conversions.get("Petabyte").put("Nibble", 2e+15);
        conversions.get("Petabyte").put("Bits", 8e+15);
        conversions.get("Petabyte").put("Bytes", 1e+15);
        conversions.get("Petabyte").put("Kilobyte", 1e+12);
        conversions.get("Petabyte").put("Megabyte", 1e+9);
        conversions.get("Petabyte").put("Gigabyte", 1000000.0);
        conversions.get("Petabyte").put("Terabyte", 1000.0);
        conversions.get("Petabyte").put("Petabyte", 1.0);
        conversions.get("Petabyte").put("Exabyte", 0.001);
        conversions.get("Petabyte").put("Zettabyte", 1e-6);
        conversions.get("Petabyte").put("Yottabyte", 1e-9);
        
        conversions.put("Exabyte", new HashMap<>());

        conversions.get("Exabyte").put("Nibble", 2e+18);
        conversions.get("Exabyte").put("Bits", 8e+18);
        conversions.get("Exabyte").put("Bytes", 1e+18);
        conversions.get("Exabyte").put("Kilobyte", 1e+15);
        conversions.get("Exabyte").put("Megabyte", 1e+12);
        conversions.get("Exabyte").put("Gigabyte", 1e+9);
        conversions.get("Exabyte").put("Terabyte", 1000000.0);
        conversions.get("Exabyte").put("Petabyte", 1000.0);
        conversions.get("Exabyte").put("Exabyte", 1.0);
        conversions.get("Exabyte").put("Zettabyte", 0.001);
        conversions.get("Exabyte").put("Yottabyte", 1e-6);
        
        conversions.put("Zettabyte", new HashMap<>());

        conversions.get("Zettabyte").put("Nibble", 2e+21);
        conversions.get("Zettabyte").put("Bits", 8e+21);
        conversions.get("Zettabyte").put("Bytes", 1e+21);
        conversions.get("Zettabyte").put("Kilobyte", 1e+18);
        conversions.get("Zettabyte").put("Megabyte", 1e+15);
        conversions.get("Zettabyte").put("Gigabyte", 1e+12);
        conversions.get("Zettabyte").put("Terabyte", 1e+9);
        conversions.get("Zettabyte").put("Petabyte", 1000000.0);
        conversions.get("Zettabyte").put("Exabyte", 1000.0);
        conversions.get("Zettabyte").put("Zettabyte", 1.0);
        conversions.get("Zettabyte").put("Yottabyte", 0.001);
        
         conversions.put("Yottabyte", new HashMap<>());

        conversions.get("Yottabyte").put("Nibble", 2e+24);
        conversions.get("Yottabyte").put("Bits", 8e+24);
        conversions.get("Yottabyte").put("Bytes", 1e+24);
        conversions.get("Yottabyte").put("Kilobyte", 1e+21);
        conversions.get("Yottabyte").put("Megabyte", 1e+18);
        conversions.get("Yottabyte").put("Gigabyte", 1e+15);
        conversions.get("Yottabyte").put("Terabyte", 1e+12);
        conversions.get("Yottabyte").put("Petabyte", 1e+9);
        conversions.get("Yottabyte").put("Exabyte", 1000000.0);
        conversions.get("Yottabyte").put("Zettabyte", 1000.0);
        conversions.get("Yottabyte").put("Yottabyte", 1.0);
    }
    public static void main(String[] args) {
        new DataConverter().go();
    }
    public void go() {
        frame = new JFrame("Data Conversions");
        fromPanel = new JPanel();
        centerLabel = new JLabel("..To..");
        fromField = new JTextField(10);
        fromBox = new JComboBox<>(DataTypes);
        toPanel = new JPanel();
        toBox = new JComboBox<>(DataTypes);
        toField = new JTextField(10);
        toField.setEnabled(false);
        welcomeLabel = new JLabel("Welcome to the Data converter!");
        submitButton = new JButton("Convert!");
        noteLabel = new JLabel("Note: Rounds to fit the text field.");
        bottomPanel = new JPanel();
        submitButton.addActionListener(new SubmitListener());

        fromPanel.setLayout(new BoxLayout(fromPanel, BoxLayout.X_AXIS));
        fromPanel.add(fromField);
        fromPanel.add(fromBox);

        toPanel.setLayout(new BoxLayout(toPanel, BoxLayout.X_AXIS));
        toPanel.add(toField);
        toPanel.add(toBox);

        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.X_AXIS));
        bottomPanel.add(noteLabel);
        bottomPanel.add(submitButton);

        Font labelFont = new Font("Arial", Font.BOLD, 24);
        welcomeLabel.setFont(labelFont);

        frame.setLayout(new BorderLayout());
        Container window = frame.getContentPane();

        window.add(BorderLayout.NORTH, welcomeLabel);
        window.add(BorderLayout.WEST, fromPanel);
        window.add(BorderLayout.EAST, toPanel);
        window.add(BorderLayout.CENTER, centerLabel);
        window.add(BorderLayout.SOUTH, bottomPanel);

        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
    class SubmitListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try
            {
            Double numToConvert = Double.parseDouble(fromField.getText());
            Double conversionRate = conversions.get(fromBox.getSelectedItem()).get(toBox.getSelectedItem());
            String result = Double.toString(numToConvert * conversionRate);
            int length = result.length();
            if (length > 4) {
                Dimension d = frame.getSize();
                frame.setSize(length + d.width - 16, d.height);
                toField.setColumns(length);
            }
            else {
                toField.setColumns(4);
                frame.pack();
            }
            toField.setText(result);
            frame.revalidate();
            }
            catch(Exception f)
{
   JOptionPane.showMessageDialog(null,"Invalid Input");
}
        }

    }
}